const promise = new Promise((resolve, reject) => {
    try{
        //
        resolve(result);
    }
    catch(err){
        reject(err);
    }
});

promise.then((result) => {   
}).catch((err)=>{
        console.error(err);
    })
function delay(ms){
    return new Promise(resolve => {
        console.log('hello')
        setTimeout(resolve, ms)});
}


delay(3000).then(()=>{
    alert('3초 후 실행')
    console.log('world')});
