const request = require('request');

var parseString = require('xml2js').parseString;


var url = "http://www.weather.go.kr/weather/forecast/mid-term-rss3.jsp?stnld=109";

//'http://newsapi.org/v2/top-headlines?' + 'country=kr&' + 'apiKey=78bc6ddd8cdb48ceac76f5f9b9dfc4c5';

request(url, function (error, response, body) {
  //console.error('error:', error); // Print the error if one occurred
  //console.log('statusCode:', response && response.statusCode); // Print the response status code if a response was received
  //console.log('body:', body); // Print the HTML for the Google homepage.
  //var jsObj = JSON.parse(body); //js Sting형태를 JSON으로 변경 
  //console.dir(jsObj.articles[0].title);
  parseString(body, function (err, result) {
    console.dir(result.rss.channel[0].item[0].description[0].header[0].wf[0]);
  });
});


