var http = require("http");

http.createServer(function (req, res) {
	var body = "hello Server";
	res.setHeader('Content-Type', 'text/html; charset=utf-8');  //text/plain
	res.end("<html><body><h1>Hello Node js Server</h1><hr/><h2>내용입니다.</h2></body></html>");
}).listen(3000);
